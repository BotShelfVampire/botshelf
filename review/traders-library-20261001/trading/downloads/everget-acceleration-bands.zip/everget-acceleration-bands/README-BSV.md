# Acceleration Bands

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/bands_and_channels/acceleration_bands.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
See a high/low envelope whose width responds to relative range.

### Logic / 仕組み
Expands high and low by a factor of their range relative to their sum, then smooths each boundary with an SMA.

### Settings / 設定
Length 20 and Factor 0.001 are the defaults. Change width independently from smoothing length.

### Limitations / 注意点
Band contact is not automatically a reversal signal. The high-plus-low denominator assumes an appropriate price series.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
相対的な高安差で幅が変わる価格帯を表示。

### Logic / 仕組み
高値と安値の和に対する値幅の比で上下を広げ、各境界を単純移動平均で平滑化します。

### Settings / 設定
初期値は期間20、Factor 0.001。線の幅と平滑化期間を分けて比較します。

### Limitations / 注意点
バンド接触は反転を保証しません。高値＋安値を分母にするため、ゼロ近辺や負値を含む系列では注意が必要です。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
