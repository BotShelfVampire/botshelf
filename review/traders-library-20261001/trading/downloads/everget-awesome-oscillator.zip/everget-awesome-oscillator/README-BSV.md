# Awesome Oscillator

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/awesome_oscillator.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Compare short and long midpoint-price momentum.

### Logic / 仕組み
Subtracts the slow SMA of hl2 from the fast SMA; histogram colors encode the sign and whether the value is increasing.

### Settings / 設定
Fast Length 5; Slow Length 34. Compare zero crossings and direction changes against the underlying chart.

### Limitations / 注意点
A rising histogram below zero is still negative momentum by this measure. No order execution or alerts are implemented here.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
高値・安値の中間価格から短期と長期の勢いを比較。

### Logic / 仕組み
中間価格の短期単純移動平均から長期平均を引き、正負と前バーからの増減で色分けします。

### Settings / 設定
初期値は短期5・長期34。ゼロラインと増減を実際の価格の動きと照合します。

### Limitations / 注意点
ゼロより下で上向いても、この指標の値はまだマイナスです。この版に発注やアラート機能はありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
