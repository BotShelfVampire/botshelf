# Fear and Greed — Price/Volume Model

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/fear_greed.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Highlight extremes in a locally calculated price/volume score.

### Logic / 仕組み
Combines centered RSI, price/EMA ratio, relative volume and relative standard deviation. It does not fetch the CNN or Alternative.me fear-and-greed index.

### Settings / 設定
Extreme Fear starts at -40; Extreme Greed at 100. First check that the selected feed supplies usable volume.

### Limitations / 注意点
Missing or zero volume can invalidate the score. Values are feed-specific; no probability is implied.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
価格と出来高から独自計算したスコアの極端値を色で表示。

### Logic / 仕組み
中心化したRSI、価格とEMAの比、相対出来高、標準偏差を掛け合わせます。CNNやAlternative.meの恐怖・強欲指数を取得するものではありません。

### Settings / 設定
恐怖側は-40、強欲側は100が初期値。使用する配信元に有効な出来高があることを先に確認します。

### Limitations / 注意点
出来高が欠落またはゼロだとスコアが成立しない場合があります。配信元で値が変わり、確率を示す数値ではありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
