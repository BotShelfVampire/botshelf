# Gaussian Process Regression

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/gaussian_regression.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Inspect a rolling regression curve and model projection.

### Logic / 仕組み
Uses an RBF kernel, a pseudoinverse and a rolling vector of demeaned closes. It redraws the fitted and projected polylines as new bars arrive.

### Settings / 設定
Start with a positive lookback, the default 100 bars and 30-bar horizon. Length Scale controls smoothness; noise input is squared in the matrix.

### Limitations / 注意点
Redrawn historical fits are not historical trading signals. Projection is not forecast accuracy evidence. Zero lookback and very large matrices can fail.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
ローリング回帰曲線とモデルによる延長線を研究。

### Logic / 仕組み
RBFカーネル、擬似逆行列、平均を引いた終値の配列で計算します。新しい足ごとに回帰線と予測線を描き直します。

### Settings / 設定
参照期間はゼロにせず、まず初期値100本・予測30本を使用。Length Scaleは滑らかさに関わり、noise入力は行列内で二乗されます。

### Limitations / 注意点
描き直された過去の曲線は当時の売買シグナルではありません。延長線が当たる証拠にはならず、参照期間ゼロや過大な行列はエラー要因です。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
