# STARC Bands — Original Source

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/bands_and_channels/stoller_average_range_channels.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Study an ATR envelope with a choice of moving-average baseline.

### Logic / 仕組み
The center supports SMA, EMA, VWMA or WMA. Width uses ATR(length) times Multiplier in the actual source.

### Settings / 設定
Length defaults to 6 and Multiplier to 1.33. The separate ATR Length input defaults to 15 but is unused.

### Limitations / 注意点
Known source defect: changing ATR Length has no effect. The original is preserved for inspection, not silently fixed.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
基準線の種類を選べるATRチャネルの原本。

### Logic / 仕組み
中央はSMA・EMA・VWMA・WMAから選択。実際の原本の幅計算はATR(length)×倍率です。

### Settings / 設定
期間6、倍率1.33が初期値。別のATR Length入力は初期値15ですが計算に使われていません。

### Limitations / 注意点
既知の不具合：ATR Lengthを変えても結果に反映されません。検証用に原本を保持し、無断で修正版に置き換えていません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
