# Range Candles — OHLC Renderer

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/highlighters/range_candles.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Use a small source example for consistent candle, border and wick colors.

### Logic / 仕組み
Redraws the existing chart OHLC. Close greater than or equal to Open selects the bullish color. It does not construct range bars.

### Settings / 設定
Only bullish and bearish colors are inputs. Check overlap with the chart’s original candles.

### Limitations / 注意点
Despite the title, this is a candle renderer, not a new range-chart calculation or trading signal.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
足・枠・ヒゲの色を揃える小さな描画サンプル。

### Logic / 仕組み
チャートにあるOHLCを描き直します。終値が始値以上なら陽線色を使用。値幅足を生成するコードではありません。

### Settings / 設定
設定は陽線色・陰線色のみ。元のチャート足との重なりを確認します。

### Limitations / 注意点
名前にRangeとありますが、ローソク足の描画サンプルで、値幅チャートの計算や売買シグナルではありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
