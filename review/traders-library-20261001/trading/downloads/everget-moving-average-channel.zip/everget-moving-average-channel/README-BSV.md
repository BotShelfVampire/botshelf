# Moving Average Channel

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/bands_and_channels/moving_average_channel.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Locate price above, inside or below a smoothed high/low channel.

### Logic / 仕組み
The upper and lower boundaries have separate SMA sources, periods and visual offsets. Candle colors compare close with the unshifted calculated boundaries.

### Settings / 設定
Both periods default to 20 and offsets to zero. Keep offsets at zero for a direct visual comparison with candle colors.

### Limitations / 注意点
A visual offset moves a drawing; it does not add future information. Colors and shifted lines can appear misaligned.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
高値・安値の平均で作るチャネルに対する価格位置を表示。

### Logic / 仕組み
上限・下限それぞれに平均する価格、期間、描画シフトを設定。足の色はシフトしていない計算値と終値を比較します。

### Settings / 設定
上下とも期間20、シフト0が初期値。足の色と位置を直接比較する場合はシフト0を保ちます。

### Limitations / 注意点
描画シフトは未来の情報を追加しません。シフトした線と足の色は位置がずれて見える場合があります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
