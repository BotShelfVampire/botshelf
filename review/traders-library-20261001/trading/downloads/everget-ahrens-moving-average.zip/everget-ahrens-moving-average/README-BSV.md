# Ahrens Moving Average

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/ahrens_moving_average.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Explore a recursive average with a delayed-average correction.

### Logic / 仕組み
Updates the previous average using the current source and the midpoint of the previous and length-bars-old average.

### Settings / 設定
Length defaults to 9. Keep it positive and allow a substantial warm-up period.

### Limitations / 注意点
Zero initialization and loaded history affect early values; changing history can change the warm-up segment.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
過去の平均値を使って補正する再帰型平均線の研究用。

### Logic / 仕組み
前回値と指定本数前の平均の中間点を基準に、現在の価格を使って平均値を更新します。

### Settings / 設定
期間9が初期値。正の期間を使い、十分な計算準備期間を取ります。

### Limitations / 注意点
ゼロ初期化と読み込んだ履歴が初期値に影響します。履歴を増やすと開始付近の値が変わる場合があります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
