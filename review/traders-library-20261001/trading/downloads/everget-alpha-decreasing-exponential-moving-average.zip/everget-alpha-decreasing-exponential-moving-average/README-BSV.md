# Alpha-Decreasing EMA

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/alpha_decreasing_exponential_moving_average.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Explore an average whose smoothing weight shrinks across loaded history.

### Logic / 仕組み
Uses alpha=2/(bar_index+1) instead of a fixed lookback period. The weight therefore depends on where chart history starts.

### Settings / 設定
There are no input settings in this original. Compare charts with different loaded history to understand the dependence.

### Limitations / 注意点
Not a fixed-period EMA. Reloaded or expanded history can change the entire trajectory.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
読み込んだ履歴の経過とともに平滑化係数が小さくなる平均。

### Logic / 仕組み
固定期間の代わりにalpha=2/(bar_index+1)を使用。チャート履歴の開始位置が係数に影響します。

### Settings / 設定
原本に設定項目はありません。履歴の長さが異なるチャートで計算の依存性を比較します。

### Limitations / 注意点
固定期間のEMAではありません。履歴の再読込・追加により軌跡全体が変化する可能性があります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
