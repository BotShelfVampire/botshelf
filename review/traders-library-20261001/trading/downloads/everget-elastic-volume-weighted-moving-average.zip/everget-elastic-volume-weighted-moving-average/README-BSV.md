# Elastic Volume Weighted Moving Average

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/elastic_volume_weighted_moving_average.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Let relative current-bar volume control a recursive average.

### Logic / 仕組み
Blends the previous average and current price using current volume divided by the rolling volume total.

### Settings / 設定
Length 14 is the default. Confirm volume availability before interpreting the result.

### Limitations / 注意点
Zero or missing volume can break the calculation. FX/CFD volume may be broker-specific tick volume, not consolidated traded volume.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
直近出来高に占める現在足の比率で平均線の反応を変える。

### Logic / 仕組み
現在出来高÷期間合計出来高を使い、前回の平均と現在価格を配分します。

### Settings / 設定
期間14が初期値。結果を読む前に出来高が存在するか確認します。

### Limitations / 注意点
出来高ゼロや欠落で計算できない場合があります。FX・CFDでは集約売買高ではなく配信元固有のティック出来高の場合があります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
