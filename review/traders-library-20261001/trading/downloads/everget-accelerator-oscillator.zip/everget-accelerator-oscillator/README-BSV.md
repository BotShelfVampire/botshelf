# Accelerator Oscillator

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/accelerator_oscillator.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Study momentum changes relative to a smoothed baseline.

### Logic / 仕組み
Calculates Awesome Oscillator from midpoint SMAs, then subtracts an SMA of that oscillator. It is a momentum residual, not a direct price forecast.

### Settings / 設定
Fast 5; Slow 34; Smoothing 5. Start with the defaults and change one length at a time in replay.

### Limitations / 注意点
Short smoothing can produce frequent sign changes. Histogram color alone is not a complete trading system.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
勢いが平滑化した基準からどの程度変化したかを表示。

### Logic / 仕組み
中間価格の平均差からAwesome Oscillatorを求め、その平均をさらに引きます。勢いの差を示すもので、将来価格を計算するものではありません。

### Settings / 設定
短期5・長期34・平滑化5。リプレイで一つずつ期間を変え、反応とダマシの違いを比較します。

### Limitations / 注意点
平滑化期間を短くすると正負の切り替わりが増えます。色だけでは損切り・決済を含む売買システムになりません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
