# Derivative Oscillator

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/derivative_oscillator.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Observe changes in a twice-smoothed RSI.

### Logic / 仕組み
Smooths RSI with EMA 5 then EMA 3, subtracts a 9-bar SMA, and overlays another 9-bar signal SMA.

### Settings / 設定
RSI 14; smoothing 5/3/9; signal 9. Keep lengths positive and compare sensitivity versus delay.

### Limitations / 注意点
The black signal line may be hard to see on dark charts; change its style color in TradingView. This is not a strategy backtest.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
二段階で平滑化したRSIの変化を確認。

### Logic / 仕組み
RSIをEMA5、EMA3の順で平滑化し、SMA9を引いた値と、そのSMA9のシグナル線を表示します。

### Settings / 設定
RSI14・平滑化5/3/9・シグナル9。期間は正の値にし、反応の速さと遅れを比較します。

### Limitations / 注意点
黒いシグナル線は暗い背景で見えにくいため、TradingViewのスタイル設定で色を調整します。ストラテジーやバックテストではありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
