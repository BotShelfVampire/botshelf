# Vortex Bands

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/bands_and_channels/vortex_bands.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Inspect a signed-deviation cloud with optional candle coloring.

### Logic / 仕組み
A two-stage exponential filter forms the basis and smooths the signed source-minus-basis difference. The two boundaries can cross.

### Settings / 設定
Length 20, Multiplier 2 and Source HLC3 are defaults. Select a coloring rule separately.

### Limitations / 注意点
This is not a standard deviation envelope or the VI+/VI− Vortex oscillator. Length 1 creates a zero denominator.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
符号付きの偏差を使う雲と、足の色分けを観察。

### Logic / 仕組み
二段の指数平滑化で中心線と価格差を計算。差の符号を残すため上下の境界線が交差する場合があります。

### Settings / 設定
期間20、倍率2、HLC3が初期値。色分けルールは別に選択します。

### Limitations / 注意点
標準偏差バンドやVI+/VI−のVortexオシレーターではありません。期間1では分母がゼロになります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
