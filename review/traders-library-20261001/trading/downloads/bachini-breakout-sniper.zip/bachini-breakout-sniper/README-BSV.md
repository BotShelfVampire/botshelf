# Breakout Sniper

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/breakout_sniper.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Explore rolling high/low breakouts and signal-based exits.

### Logic / 仕組み
The rolling extreme includes the current bar. Reaching that extreme triggers an entry request. The holding counter measures bars since the latest breakout signal, not bars since entry.

### Settings / 設定
Lookback starts at 365 bars and Holding Period at 30 bars. Test a shorter sample visually before increasing history.

### Limitations / 注意点
No stop-loss. Repeated signals reset the exit counter. The lower plot is also labelled HIGH in the original code.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
過去の高安を使うブレイクアウトと、シグナル経過本数による決済の検証用。

### Logic / 仕組み
現在足を含む範囲の高値・安値への到達で注文を要求します。保有期間のカウントは建値の足からではなく、直近シグナルからの経過本数です。

### Settings / 設定
参照期間は365本、保有期間入力は30本が初期値。短い期間で注文位置を目視してから履歴を広げます。

### Limitations / 注意点
損切りはありません。シグナルが繰り返されると決済カウントがリセットされます。原本では下側の線もHIGH表記です。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
