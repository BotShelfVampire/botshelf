# Distance Weighted Moving Average

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/distance_weighted_moving_average.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Inspect an average weighted by price proximity rather than time.

### Logic / 仕組み
Each sample receives inverse total absolute distance to all other samples in the window; weighted prices are then normalized.

### Settings / 設定
Length defaults to 14. Keep windows modest because the nested loops scale quadratically.

### Limitations / 注意点
Known edge case: identical prices or Length 1 produce zero distances and division by zero.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
時系列の新しさではなく価格同士の近さで加重する平均。

### Logic / 仕組み
各価格と窓内の全価格との絶対差合計の逆数を重みにし、加重合計を正規化します。

### Settings / 設定
期間14が初期値。二重ループで計算量が増えるため期間を過度に大きくしません。

### Limitations / 注意点
既知の境界条件：同じ価格が並ぶ場合や期間1では、距離ゼロによるゼロ除算が起こります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
