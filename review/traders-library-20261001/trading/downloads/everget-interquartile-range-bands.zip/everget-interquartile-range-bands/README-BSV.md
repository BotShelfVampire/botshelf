# Interquartile Range Bands

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/bands_and_channels/interquartile_range_bands.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Study outliers against a rolling median and quartiles.

### Logic / 仕組み
Calculates nearest-rank 25th, 50th and 75th percentiles. The outer bands extend Q1 and Q3 by a multiple of Q3 minus Q1.

### Settings / 設定
Length 14 and Multiplier 1.5 are the defaults.

### Limitations / 注意点
A short window yields stepped estimates. Statistical outliers are not a guarantee that price will revert.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
移動する中央値と四分位数で価格の外れを観察。

### Logic / 仕組み
直近系列の25・50・75パーセンタイルを計算。第1・第3四分位から四分位範囲の倍率分だけ外へ広げます。

### Settings / 設定
期間14、倍率1.5が初期値です。

### Limitations / 注意点
短い窓では値が段階的に変わります。統計上の外れ値でも価格が戻るとは限りません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
