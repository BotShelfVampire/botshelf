# Forecast Oscillator

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/forecast_oscillator.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Compare price with the current endpoint of a rolling linear regression.

### Logic / 仕組み
Shows 100 × (source − current regression endpoint) / source. Despite its name, the script does not produce a future price target.

### Settings / 設定
Length 14 and close are defaults. Compare sign changes and deviation size with the actual price path.

### Limitations / 注意点
The denominator is the source price. Regression fit and a positive oscillator do not establish predictive accuracy.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
現在価格とローリング回帰線の終点の差を比較。

### Logic / 仕組み
100 ×（価格−現在の回帰線終点）÷価格を表示します。名称にForecastとありますが、将来の価格目標は出しません。

### Settings / 設定
初期値は期間14・終値。正負の変化と乖離幅を実際の値動きと照合します。

### Limitations / 注意点
分母は入力価格です。回帰への適合や値のプラスだけでは予測精度を証明できません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
