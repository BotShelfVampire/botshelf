# Arnaud Legoux Moving Average

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/arnaud_legoux_moving_average.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Compare a smooth ALMA trend line with a standard average.

### Logic / 仕組み
Calls Pine’s ALMA function on the chosen price series. Offset and Sigma adjust the weighting profile.

### Settings / 設定
Length 9, Offset 0.85 and Sigma 6 are the original defaults.

### Limitations / 注意点
This is Pine v3 source. Keep its version header; conversion to a newer version requires a separate compile check.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
通常の移動平均とALMAの滑らかさ・追従性を比較。

### Logic / 仕組み
選択した価格系列にPineのALMA関数を適用。OffsetとSigmaで重みの分布を調整します。

### Settings / 設定
原本の初期値はLength 9、Offset 0.85、Sigma 6です。

### Limitations / 注意点
Pine v3の原本です。バージョン行を維持し、新版への変換後は別途コンパイル確認が必要です。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
