# Ehlers Cyber Cycle

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/ehlers_cyber_cycle.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Inspect a recursive cycle filter and its one-bar trigger.

### Logic / 仕組み
Applies a four-price smoothing kernel and a second-difference recursive filter controlled by Alpha. The trigger is the prior-bar filter value.

### Settings / 設定
Alpha defaults to 0.7. The Length input defaults to 14 but is not used in this source calculation.

### Limitations / 注意点
Known issue: changing Length has no effect. The unconstrained Alpha input can produce unstable settings. Historical initialization can affect early values.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
再帰型サイクルフィルターと1バー前のトリガーを比較。

### Logic / 仕組み
4価格の加重平滑化に二階差分と再帰処理を組み合わせます。Alphaが係数を決め、トリガーには1バー前の値を使います。

### Settings / 設定
Alphaの初期値は0.7。Lengthは初期値14ですが、この原本の計算では使われていません。

### Limitations / 注意点
既知の問題：Lengthを変えても計算は変わりません。Alphaには範囲制約がなく、不安定な設定になり得ます。初期化は序盤の値にも影響します。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
