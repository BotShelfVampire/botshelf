# Price Channels

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/price_channels.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Backtest a long-only return inside an EMA/ATR channel.

### Logic / 仕組み
Builds a channel around EMA(21) using ATR(14) times two. A close crossing above the lower band requests a long. Crossing the upper band or elapsed signal time requests an exit.

### Settings / 設定
EMA length, Holding Period and Multiplier are inputs. ATR length is fixed at 14 in this source.

### Limitations / 注意点
No short entries or stop-loss. The comment says days, but the holding parameter counts chart bars.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
EMAとATRのチャネル内へ戻る動きを買いのみで検証。

### Logic / 仕組み
EMA21を中心にATR14の2倍幅のチャネルを描きます。終値の下限上抜けで買い、上限上抜けやシグナル後の経過本数で決済を要求します。

### Settings / 設定
EMA期間、保有期間、倍率が設定項目。ATR期間は原本のコード内で14に固定されています。

### Limitations / 注意点
売りエントリーと損切りはありません。コメントはdaysですが、保有期間はチャートの本数です。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
