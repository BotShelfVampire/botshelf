# Dorsey Inertia

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/dorsey_inertia.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Separate directional volatility and smooth it into a relative-strength curve.

### Logic / 仕組み
Calculates a Relative Volatility Index separately on highs and lows, averages them, then takes a rolling regression endpoint.

### Settings / 設定
Standard deviation 21; RVI smoothing 14; inertia smoothing 14. The reference level is 50.

### Limitations / 注意点
RVI here means Relative Volatility Index, not Relative Vigor Index. Flat series can make the volatility denominator zero.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
方向別のボラティリティを平滑化して相対的な強弱を表示。

### Logic / 仕組み
高値と安値それぞれのRelative Volatility Indexを平均し、ローリング回帰線の終点を求めます。

### Settings / 設定
標準偏差21・RVI平滑化14・慣性平滑化14。基準線は50です。

### Limitations / 注意点
ここでのRVIはRelative Volatility Indexで、Relative Vigor Indexとは別物です。変化のない系列では分母がゼロになる場合があります。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
