# Simple Moving Average

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/sma.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
A minimal trend baseline and a readable first Pine indicator.

### Logic / 仕組み
Plots the arithmetic mean of closing prices over the selected number of bars. It neither places orders nor produces a backtest.

### Settings / 設定
Length defaults to 200 bars, not 200 days. Compare the line with price and change only the period first.

### Limitations / 注意点
The average lags price. A price cross alone is not a validated trading edge.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
トレンドの基準線とPine学習の最初の一本に。

### Logic / 仕組み
指定本数の終値の単純平均を表示します。注文やバックテストは行いません。

### Settings / 設定
初期値は200本です。200日ではありません。まず期間だけを変え、価格との位置関係を比較します。

### Limitations / 注意点
平均線は価格に遅れて動きます。価格との交差だけで有効な売買ルールとは判断できません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
