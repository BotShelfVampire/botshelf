# Adaptive Laguerre Filter

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/movings/adaptive_laguerre_filter.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Explore adaptive smoothing with a configurable color-change alert.

### Logic / 仕組み
Normalizes recent price-to-filter differences, takes a median-derived weight, and runs four recursive Laguerre stages.

### Settings / 設定
Length 14, Median Length 5 and Await Bar Confirmation enabled are defaults. Create the alert explicitly in TradingView.

### Limitations / 注意点
The confirmation option gates color/alerts, not the underlying live calculation. It is not a blanket non-repainting certification.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
適応型平滑化と色変化アラートを検証。

### Logic / 仕組み
価格とフィルターの差を正規化し、その中央値から係数を求め、四段の再帰計算を行います。

### Settings / 設定
期間14、中央値期間5、確定待ち有効が初期値。アラート自体はTradingViewで作成します。

### Limitations / 注意点
確定待ちは色とアラートの条件に作用し、計算自体を固定しません。非リペイントを全面保証する機能ではありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
