# Center of Gravity Oscillator

Original author: Alex Orekhov (everget)
Source: https://github.com/everget/tradingview-pinescript-indicators/blob/60c93d3711d222b8f2db96160defe568429348e0/oscillators/center_of_gravity_oscillator.pine
Pinned commit: 60c93d3711d222b8f2db96160defe568429348e0
License: GPL-3.0-only (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Explore a price-weighted oscillator against its prior-bar trigger.

### Logic / 仕組み
Divides the negative sum of price × bar distance by the sum of prices. The second line is the oscillator one bar earlier.

### Settings / 設定
Length 10; source hl2; optional fill. Compare line crosses in replay instead of treating the smooth historical view as a trade log.

### Limitations / 注意点
The sum-of-prices denominator must not be zero. No explicit fixed overbought/oversold thresholds are supplied.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
価格で重み付けしたオシレーターと前バーの値を比較。

### Logic / 仕組み
価格×バー距離の合計にマイナスを付け、価格合計で割ります。もう一本は一つ前のバーの値です。

### Settings / 設定
期間10・中間価格が初期値。塗りつぶしは任意です。過去の滑らかな表示を売買実績と扱わず、リプレイで交差を比較します。

### Limitations / 注意点
価格合計がゼロの系列には注意が必要です。固定の買われすぎ・売られすぎ水準は設定されていません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
