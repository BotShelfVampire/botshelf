# Spike Trader

Original author: EarnForex
Source: https://github.com/EarnForex/Spike-Trader/tree/abc322e8da3c7fc9c701d056f01a70ebe4e20cd5
Pinned commit: abc322e8da3c7fc9c701d056f01a70ebe4e20cd5
License: Apache-2.0 (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Study a counter-spike trading rule with separate MT4 and MT5 source implementations. Research and isolated demo use only.

### Logic / 仕組み
On a new chart bar, tests whether the last completed bar extended beyond the preceding highs or lows, exceeded a relative-price threshold, and closed back inside a defined share of its range. It trades against that spike, reverses on an opposite signal, and uses an in-memory bar timer to close positions.

### Settings / 設定
Original defaults: Hold 11 bars; BarsNumber 3; PercentageDifference 0.003 (0.3%); ThirdOrHalf 0.5; Lots 0.1; Slippage 30 points. These are upstream defaults, not a recommended setup. Compile the matching platform file and test only in an isolated demo environment after reading the known issues.

### Limitations / 注意点
The author warns this EA can lose all funds. The original code lacks a protective stop, and the MT5 variant can manage unrelated same-symbol positions. This bundle preserves the original for study; it is not a live-ready product or an endorsement of its historic backtest claims.

### Known source issues / 原本の既知の問題
- No broker-side stop-loss or take-profit is placed: both values are zero in entry calls.
- MT5 selects and closes by symbol without a magic-number filter. It may interfere with manual or other-EA positions on the same symbol.
- MT5 logs a CopyRates failure but continues indexing the array. Insufficient history can cause an error.
- The hold timer exists only in memory and resets on reattachment/restart. Repeated same-direction signals reset the timer.
- MT4 ClosePrev can return true after a close failure; MT5 does not check trade result codes. A failed close is not guaranteed to prevent a new entry.

### Install / 導入
1. Download the source bundle and extract it. Use .mq4 in MT4 and .mq5 in MT5; these are different languages and cannot be swapped by renaming. Keep LICENSE.txt.
2. In the matching desktop terminal choose File → Open Data Folder. Copy this EA source under MQL4/Experts or MQL5/Experts. Preserve include/folder structure if the author’s package has it.
3. Open the matching MetaEditor, compile the main source, and resolve errors and missing dependencies. Check the tool-specific notes before enabling any permission. Do not enable DLL or external-web access simply to make an error disappear.
4. Use Strategy Tester and an isolated demo account with no other positions first. Confirm entries, exits, order filters, costs, restart behavior and failures. Reading source is not a substitute for those checks.

Dependencies: MT4: no external includes found. MT5: standard terminal Trade/Trade.mqh and Trade/PositionInfo.mqh, not redistributed in this bundle.

## 日本語

### Purpose / 目的
急な高安更新に逆方向で入る条件を、MT4・MT5それぞれの原本で学ぶEA。研究・隔離したデモ環境用です。

### Logic / 仕組み
新しいバーで直前の確定バーを調べ、過去高安の更新・一定比率以上の伸び・値幅の内側への戻りを判定します。スパイクに逆方向で入り、反対シグナルで反転。メモリー内のバー数タイマーで決済します。

### Settings / 設定
原本の初期値はHold 11バー・BarsNumber 3・PercentageDifference 0.003（0.3%）・ThirdOrHalf 0.5・Lots 0.1・Slippage 30ポイント。推奨設定ではありません。対応する版をコンパイルし、既知の問題を読んでから隔離したデモ環境で試します。

### Limitations / 注意点
作者は全資金を失う可能性を警告しています。原本に保護ストップがなく、MT5版は同一銘柄の他ポジションにも干渉し得ます。研究用に原本を保持した配布で、実運用向け製品や過去のバックテスト成績の推奨ではありません。

### Known source issues / 原本の既知の問題
- 新規注文で損切り・利確の価格に0を渡しており、サーバー側の保護注文は入りません。
- MT5版は銘柄だけでポジションを選択・決済し、マジックナンバーを絞り込みません。同じ銘柄の手動注文や他EAへ干渉する可能性があります。
- MT5版はCopyRatesの取得失敗を記録しても処理を止めず、配列へアクセスします。履歴不足時にエラーになり得ます。
- 保有タイマーはメモリー内だけで保持され、再起動や付け直しで初期化されます。同方向シグナルが出ると再設定されます。
- MT4版は決済失敗後もClosePrevがtrueを返す経路があり、MT5版も注文結果を確認しません。決済できなかった場合の新規注文停止は保証されません。

### Install / 導入
1. ソース一式を取得して展開します。.mq4はMT4、.mq5はMT5用です。名前を変えるだけでは変換できません。LICENSE.txtも保持します。
2. 対応するデスクトップ版で「ファイル→データフォルダを開く」を選び、EAをMQL4/ExpertsまたはMQL5/Expertsへ置きます。作者のパッケージに付属フォルダがある場合は階層を崩しません。
3. 対応するMetaEditorで本体をコンパイルし、エラーと依存不足を確認します。各ツールの注意点を読み、エラーを消す目的だけでDLLや外部通信を許可しないでください。
4. まず他のポジションがないテスター・隔離したデモ口座で、新規注文・決済・対象の絞り込み・コスト・再起動・失敗時の処理を確認します。ソースを読むだけではこれらの実行確認の代わりになりません。

Dependencies: MT4版は外部インクルードなし。MT5版はターミナル標準のTrade/Trade.mqhとTrade/PositionInfo.mqhが必要です。標準ライブラリはこの配布物に含めません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
