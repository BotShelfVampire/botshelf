# Moving Average Cross

Original author: James Bachini
Source: https://github.com/jamesbachini/Pine-Script-Examples/blob/6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79/crossover.ps
Pinned commit: 6d14308f8ce42b2d60ec6c80eb224e8f4ffb3a79
License: MIT (see LICENSE.txt). Original source is unmodified.

BSV explanatory notes follow. They do not replace the source license.

## English

### Purpose / 目的
Study a complete long/short moving-average crossover backtest.

### Logic / 仕組み
Uses 30- and 200-bar simple moving averages. Crossovers request a long entry and close the short; crossunders do the reverse. Inspect the order list because reversals and explicit closes interact.

### Settings / 設定
Set short and long periods. In Strategy Tester, set capital, order size, commission and slippage before comparing runs.

### Limitations / 注意点
No protective stop-loss is implemented. TradingView simulated orders are not a broker-connected automated system.

### Install / 導入
1. Download the source-and-license ZIP and extract it. Keep LICENSE.txt with the source when you share a copy.
2. Open a TradingView chart, open Pine Editor, and create a blank script. Paste the chosen Pine source, preserving its version line. The .ps files in this collection are Pine Script examples, not PowerShell programs.
3. Save and use Add to chart. For Pine v3/v4 code, try the original version first; use TradingView’s official migration tools sequentially if conversion is necessary. Compilation has not been performed by BSV.
4. Open Inputs and Style. Reproduce a small historical example, then use replay and an isolated paper workflow to observe how the current bar changes. A plotted indicator does not automatically place orders.

## 日本語

### Purpose / 目的
移動平均線の交差で売買する両方向ストラテジーの検証用。

### Logic / 仕組み
30本と200本の単純移動平均を使います。上抜けで買いと売りの決済、下抜けで売りと買いの決済を要求します。反転注文と明示的な決済が重なるため注文一覧も確認します。

### Settings / 設定
短期・長期の期間を設定。ストラテジーテスターで資金、数量、手数料、スリッページを設定してから比較します。

### Limitations / 注意点
保護用の損切り注文は実装されていません。TradingView上のシミュレーションであり、証券会社に接続した自動売買ではありません。

### Install / 導入
1. ソースとライセンスのZIPを取得して展開します。再配布する際はLICENSE.txtを原本と一緒に保持します。
2. TradingViewのチャートでPineエディタを開き、空のスクリプトへ貼り付けます。先頭のバージョン指定を残します。このライブラリの.psはPine Scriptで、PowerShell用ではありません。
3. 保存してチャートに追加します。Pine v3/v4はまず原版のまま確認し、変換が必要なら公式の移行機能で段階的に移行します。BSVではコンパイルを実施していません。
4. 入力とスタイルを設定し、小さな過去例を再現します。リプレイと隔離したペーパー環境で未確定バーの変化を観察します。インジケーターの表示だけで自動発注されるわけではありません。


Verification: source and license bytes checked; no compilation, backtest, demo or live run by BSV. No profit claim.
